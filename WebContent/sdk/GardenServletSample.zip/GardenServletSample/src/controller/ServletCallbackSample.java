package controller;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson.JacksonFactory;

import swssm.garden.sdk.AbstractAuthorizationCodeCallbackServlet;
import swssm.garden.sdk.AuthorizationCodeFlow;
import swssm.garden.sdk.AuthorizationCodeResponseUrl;
import swssm.garden.sdk.TokenResponse;

public class ServletCallbackSample extends AbstractAuthorizationCodeCallbackServlet {

	private static final long serialVersionUID = 1L;
	@Override
	protected void onError(HttpServletRequest req, HttpServletResponse resp,
			AuthorizationCodeResponseUrl errorResponse)
			throws ServletException, IOException {
		redirectAfterErrorAuth(req,resp, "http://localhost:8080/GardenServletSample/");
	}
	@Override
	protected void onSuccess(HttpServletRequest req, HttpServletResponse resp,
			TokenResponse tokenResponse) throws ServletException, IOException {
		redirectAfterSuccessAuth(req,resp, "http://localhost:8080/GardenServletSample/login_success");
		System.out.println("******************************************");
		System.out.println("access token : " + tokenResponse.getAccessToken());
		System.out.println("******************************************");
		
	}

	@Override
	protected String getRedirectUri(HttpServletRequest req)
			throws ServletException, IOException {
		GenericUrl url = new GenericUrl(req.getRequestURL().toString());
	    url.setRawPath(ServletSample.Redirect_Uri);
	    return url.build();
	}


	@Override
	protected AuthorizationCodeFlow initializeFlow() throws ServletException,
			IOException {
		AuthorizationCodeFlow flow = new AuthorizationCodeFlow.Builder(
		        new BasicAuthentication(ServletSample.Garden_Client_ID, ServletSample.Garden_Client_Secret),
		        ServletSample.Garden_Client_ID).setScopes(Arrays.asList(ServletSample.SCOPE))
			        .setApprovalPrompt("auto")
	                .build();
		return flow;
	}

}