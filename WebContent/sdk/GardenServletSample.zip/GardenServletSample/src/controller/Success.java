package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import swssm.garden.sdk.Clients;


/**
 * Servlet implementation class Sucess
 */
@WebServlet("/login_success")
public class Success extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String accessToken = (String)session.getAttribute("access_token");	
		System.out.println("success session tests : " + accessToken);
		Clients client = new Clients(accessToken);
		PrintWriter out = response.getWriter();
	    out.println("<html><body>");
	    out.println("<meta http-equiv='Content-Type' content='text/html;' charset='UTF-8'>");
	    out.println("Client 이름 : " + client.getProfiles().getName());
	    out.println("Client 이름 : " + client.getProfiles().getClassNum());
	    out.println("Client 앱[0] : " + client.getAppList().get(0).getDisplayName());
	    out.println("Client 프로젝트[0] " + client.getProjectList().get(0).getDisplayName());
	    out.println("</body></html>");

		
		System.out.println(client.getProfiles());
		System.out.println(client.getAppList());
		System.out.println(client.getProjectList());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	

}
