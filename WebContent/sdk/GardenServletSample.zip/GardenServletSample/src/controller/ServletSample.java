package controller;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson.JacksonFactory;

import swssm.garden.sdk.AbstractAuthorizationCodeServlet;
import swssm.garden.sdk.AuthorizationCodeFlow;

/**
 * Servlet implementation class ServletSample
 */

public class ServletSample extends AbstractAuthorizationCodeServlet {
	
	private static final long serialVersionUID = 1L;
	
	public static final String Garden_Client_ID = "zwaHKeoAFzxpdpNDnclG32AXUCKqBd7KbfnG5WTv";
	public static final String Garden_Client_Secret = "BaB7SFkSTiUPmAoqQvFGPIYJPrTlw81vwaKpLxTxeXoRDt0cvixsbMTWAX5PV6kvXPNljZRsXLC3T2E5bep5QLeyK61u0bvRDlIbVsoYSzckaulJ8h5GLkIZ5DeKmzuY";

	public static final String SCOPE = "read";
	public static final String Redirect_Uri = "/GardenServletSample/garden2callback";
	
	
	@Override
	protected String getRedirectUri(HttpServletRequest req) throws ServletException, IOException {
		GenericUrl url = new GenericUrl(req.getRequestURL().toString());
		url.setRawPath(Redirect_Uri);
		return url.build();
	}

	@Override
	protected AuthorizationCodeFlow initializeFlow() throws ServletException, IOException {
		AuthorizationCodeFlow flow = new AuthorizationCodeFlow.Builder(
					new BasicAuthentication(Garden_Client_ID, Garden_Client_Secret),Garden_Client_ID)
					.setScopes(Arrays.asList(SCOPE))
					.setApprovalPrompt("auto")
					.build();
		
		return flow;
		
	}

}


